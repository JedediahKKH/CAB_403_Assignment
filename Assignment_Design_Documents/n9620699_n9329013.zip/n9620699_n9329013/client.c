#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <string.h> 
#include <netdb.h> 
#include <sys/types.h> 
#include <netinet/in.h> 
#include <sys/socket.h> 
#include <unistd.h>
#include "game.c"

	#define MAXDATASIZE 100 /* max number of bytes we can get at once */

	#define USERNAME_SIZE 20 /* username array size */

	#define PASSWORD_SIZE 6 /* password array size */

char success[100] = "match";

char *fromServer;
char username[USERNAME_SIZE] = {};
char password[PASSWORD_SIZE] = {};

int sockfd;  
struct hostent *he;
struct sockaddr_in their_addr; /* connector's address information */

/* Send data to server function*/
void Send_Data(int socket_id, char *myArray) {
	send(socket_id, myArray, sizeof(myArray), 0);
}

/* Recieve data from server function*/
char *Recieve_Data(int socket_identifier, int size) {
    int number_of_bytes = 0;
	
	char *results = (char*)malloc(sizeof(char)*size);
	
	if ((number_of_bytes=recv(socket_identifier, results, sizeof(results), 0)) == -1) {
		perror("recv");
		exit(EXIT_FAILURE);			
		    
	}
	return results;
}

/* creates client socket*/
void createSocket(int argc, char *argv[]){

	if (argc != 3) {
		fprintf(stderr,"usage: client_hostname port_number (client)\n");
		exit(1);
	}

	if ((he=gethostbyname(argv[1])) == NULL) {  /* get the host info */
		herror("gethostbyname");
		exit(1);
	}

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}


	their_addr.sin_family = AF_INET;      /* host byte order */
	their_addr.sin_port = htons(atoi(argv[2]));    /* short, network byte order */
	their_addr.sin_addr = *((struct in_addr *)he->h_addr);
	bzero(&(their_addr.sin_zero), 8);     /* zero the rest of the struct */

	if (connect(sockfd, (struct sockaddr *)&their_addr, \
	sizeof(struct sockaddr)) == -1) {
		perror("connect");
		exit(1);
	}
}

/* Displays Welcome and log in screen  */
void game(){
	
	draw_welcome();

	/* Ask for username */
	printf("Username: ");
	scanf("%s", username);
	Send_Data(sockfd, username);

	/* Ask for password */
	printf("Password: ");
	scanf("%s", password);
	Send_Data(sockfd, password);

	/* Receive message back from server */
	fromServer = Recieve_Data(sockfd, MAXDATASIZE);

	/* Compare received message with stored message*/
	if(strcmp(fromServer, success) == 0){
		place_mines();
		while(play){
		draw_Minesweeper_menu();
		play_game();		
		}
		close(sockfd);
	}else{
		//printf("\nYou entered either an incorrect username or password. Disconnecting...\n\n");
		draw_login_failure();		
		close(sockfd);
		exit(1);	
	}
}

int main(int argc, char *argv[]) {
	createSocket(argc, argv);
	game();
	return 0;
}
